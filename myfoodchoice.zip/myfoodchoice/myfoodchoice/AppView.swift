import SwiftUI

struct AppView: View {
    @StateObject private var loginViewModel = LoginViewModel()
    @State private var isLoggedIn = false
    
    var body: some View {
        Group {
            if loginViewModel.isLoggedIn {
                ContentView()
            } else {
                LoginView(viewModel: loginViewModel, isLoggedIn: $isLoggedIn)
            }
        }
        .onChange(of: loginViewModel.isLoggedIn) { newValue in
            isLoggedIn = newValue
        }
    }
} 