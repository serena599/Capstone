import SwiftUI

/// 食物项目模型
struct FoodItem: Identifiable, Codable {
    let id: UUID
    var serverId: Int?
    var name: String
    var calories: Int
    var unit: String
    var amount: Double?
    var mealType: MealType?
    var date: Date
    
    enum CodingKeys: String, CodingKey {
        case id = "local_id"      // 本地 UUID
        case serverId = "db_id"   // 数据库 ID
        case name
        case calories
        case unit
        case amount
        case mealType
        case date
    }
    
    // 自定义解码
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = UUID()
        serverId = try? container.decode(Int.self, forKey: .serverId)
        name = try container.decode(String.self, forKey: .name)
        calories = try container.decode(Int.self, forKey: .calories)
        unit = try container.decode(String.self, forKey: .unit)
        amount = try? container.decodeIfPresent(Double.self, forKey: .amount)
        mealType = try? container.decodeIfPresent(MealType.self, forKey: .mealType)
        date = try container.decode(Date.self, forKey: .date)
    }
    
    // 自定义编码
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encodeIfPresent(serverId, forKey: .serverId)
        try container.encode(name, forKey: .name)
        try container.encode(calories, forKey: .calories)
        try container.encode(unit, forKey: .unit)
        try container.encodeIfPresent(amount, forKey: .amount)
        try container.encodeIfPresent(mealType, forKey: .mealType)
        try container.encode(date, forKey: .date)
    }
    
    // 初始化方法
    init(id: UUID = UUID(), 
         serverId: Int? = nil, 
         name: String, 
         calories: Int, 
         unit: String = "g",
         amount: Double? = nil,
         mealType: MealType? = nil,
         date: Date) {
        self.id = id
        self.serverId = serverId
        self.name = name
        self.calories = calories
        self.unit = unit
        self.amount = amount
        self.mealType = mealType
        self.date = date
    }
}

// 在文件顶部添加这些结构体定义（在 FoodItem 之前）
struct APIResponse<T: Codable>: Codable {
    let message: String
    let data: T
}

struct MealRecordResponse: Codable {
    let id: String  // 改为 String 类型，因为是 UUID
    let food_id: Int
    let name: String
    let calories: Int
    let unit: String
    let amount: Double
    let meal_type: String
    let record_date: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case food_id
        case name
        case calories
        case unit
        case amount
        case meal_type
        case record_date
    }
}

// 添加网络服务
class NetworkService {
    static let shared = NetworkService()
    private let baseURL = "http://localhost:4000/api"
    
    private let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        decoder.dateDecodingStrategy = .formatted(formatter)
        return decoder
    }()
    
    private let encoder: JSONEncoder = {
        let encoder = JSONEncoder()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        encoder.dateEncodingStrategy = .formatted(formatter)
        return encoder
    }()
    
    func getAllFoods() async throws -> [FoodItem] {
        guard let url = URL(string: "\(baseURL)/foods") else {
            throw URLError(.badURL)
        }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        // 直接解析 JSON 数据
        if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
           let foodsData = json["data"] as? [[String: Any]] {
            
            return try foodsData.map { foodDict in
                // 创建包含必要字段的新字典
                let processedDict: [String: Any] = [
                    "name": foodDict["name"] as? String ?? "",
                    "calories": foodDict["calories"] as? Int ?? 0,
                    "unit": foodDict["unit"] as? String ?? "g"
                ]
                
                // 将字典转换为 JSON 数据
                let foodData = try JSONSerialization.data(withJSONObject: processedDict)
                // 解码为 FoodItem
                return try decoder.decode(FoodItem.self, from: foodData)
            }
        }
        throw URLError(.badServerResponse)
    }
    
    func addFood(_ food: FoodItem) async throws -> Int {
        guard let url = URL(string: "\(baseURL)/foods") else {
            throw URLError(.badURL)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // 只发送数据库表中存在的字段
        let foodData: [String: Any] = [
            "name": food.name.trimmingCharacters(in: .whitespacesAndNewlines),
            "calories": food.calories,
            "unit": food.unit.trimmingCharacters(in: .whitespacesAndNewlines)
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: foodData)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        if let httpResponse = response as? HTTPURLResponse,
           !(200...299).contains(httpResponse.statusCode) {
            throw URLError(.badServerResponse)
        }
        
        if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
           let responseData = json["data"] as? [String: Any],
           let id = responseData["id"] as? Int {
            return id
        }
        
        throw URLError(.badServerResponse)
    }
    
    func getMealRecords(userId: Int, date: Date? = nil, mealType: MealType? = nil) async throws -> [FoodItem] {
        var urlComponents = URLComponents(string: "\(baseURL)/meal-records/\(userId)")!
        var queryItems: [URLQueryItem] = []
        
        if let date = date {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd"
            queryItems.append(URLQueryItem(name: "date", value: formatter.string(from: date)))
        }
        
        if let mealType = mealType {
            queryItems.append(URLQueryItem(name: "meal_type", value: mealType.rawValue))
        }
        
        if !queryItems.isEmpty {
            urlComponents.queryItems = queryItems
        }
        
        guard let url = urlComponents.url else {
            throw URLError(.badURL)
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }
        
        let apiResponse = try decoder.decode(APIResponse<[MealRecordResponse]>.self, from: data)
        
        return apiResponse.data.map { record in
            FoodItem(
                id: UUID(),  // 生成新的本地 UUID
                serverId: Int(record.food_id),  // 使用 food_id 作为 serverId
                name: record.name,
                calories: record.calories,
                unit: record.unit,
                amount: record.amount,
                mealType: MealType(rawValue: record.meal_type) ?? .breakfast,
                date: DateFormatter.yyyyMMdd.date(from: record.record_date) ?? Date()
            )
        }
    }
    
    func addMealRecord(userId: Int, food: FoodItem) async throws {
        guard let url = URL(string: "\(baseURL)/foods") else {
            throw URLError(.badURL)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let record: [String: Any] = [
            "name": food.name.trimmingCharacters(in: .whitespacesAndNewlines),
            "calories": food.calories,
            "unit": food.unit.trimmingCharacters(in: .whitespacesAndNewlines),
            "date": ISO8601DateFormatter().string(from: food.date),
            "user_id": userId,
            "meal_type": food.mealType?.rawValue ?? "breakfast",
            "amount": food.amount ?? 1.0
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: record)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        // 打印响应数据用于调试
        if let responseString = String(data: data, encoding: .utf8) {
            print("Server response:", responseString)
        }
        
        // 检查 HTTP 状态码并解析错误信息
        if let httpResponse = response as? HTTPURLResponse {
            print("HTTP status code:", httpResponse.statusCode)
            
            // 尝试解析响应数据
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                if !(200...299).contains(httpResponse.statusCode) {
                    let errorMessage = json["error"] as? String ?? json["message"] as? String ?? "Unknown error"
                    let details = json["details"] ?? "No details available"
                    print("Error details:", details)
                    throw NSError(
                        domain: "FoodAppError",
                        code: httpResponse.statusCode,
                        userInfo: [
                            NSLocalizedDescriptionKey: errorMessage,
                            "details": String(describing: details)
                        ]
                    )
                }
                
                print("Success response:", json)
            }
        }
    }
    
    // 添加删除方法
    func deleteMealRecord(id: String) async throws {
        guard let url = URL(string: "\(baseURL)/meal-records/\(id)") else {
            throw URLError(.badURL)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }
    }
}

struct IdResponse: Codable {
    let id: Int
}

struct MealRecord: Codable {
    let userId: Int
    let foodId: Int
    let amount: Double
    let mealType: MealType
    let recordDate: Date
    
    enum CodingKeys: String, CodingKey {
        case userId = "user_id"
        case foodId = "food_id"
        case amount
        case mealType = "meal_type"
        case recordDate = "record_date"
    }
}

// 用于处理任意类型的值
struct AnyCodable: Codable {
    let value: Any
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            value = NSNull()
        } else if let bool = try? container.decode(Bool.self) {
            value = bool
        } else if let int = try? container.decode(Int.self) {
            value = int
        } else if let double = try? container.decode(Double.self) {
            value = double
        } else if let string = try? container.decode(String.self) {
            value = string
        } else {
            value = NSNull()
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch value {
        case is NSNull:
            try container.encodeNil()
        case let bool as Bool:
            try container.encode(bool)
        case let int as Int:
            try container.encode(int)
        case let double as Double:
            try container.encode(double)
        case let string as String:
            try container.encode(string)
        case let float as Float:
            try container.encode(float)
        default:
            try container.encodeNil()
        }
    }
}

@main
struct foodApp: App {
    @StateObject private var viewModel = FoodViewModel()
    
    var body: some Scene {
        WindowGroup {
            AppView()  // 使用 AppView 作为根视图
                .environmentObject(viewModel)
        }
    }
}

/// 全局视图模型
class FoodViewModel: ObservableObject {
    // MARK: - Published 属性
    @Published var selectedImage: UIImage?
    @Published var searchTerm = ""
    @Published var foodItems: [FoodItem] = []
    @Published var recentHistory: [FoodItem] = []
    @Published var showImagePicker = false
    @Published var showCamera = false
    @Published var showPopup = false
    @Published var mealCounts: [MealType: Int] = [:]
    @Published var selectedDate = Date()
    
    // 添加用户 ID
    let userId = 1 // 这里应该从用户认证系统获取
    
    init() {
        Task {
            await loadFoods()
        }
    }
    
    // 加载所有食物
    @MainActor
    func loadFoods() async {
        do {
            foodItems = try await NetworkService.shared.getMealRecords(userId: userId)
            print("Successfully loaded foods:", foodItems.count)
        } catch {
            print("Error loading foods:", error)
            if let urlError = error as? URLError {
                print("URL Error:", urlError.localizedDescription)
            } else {
                print("Other Error:", error.localizedDescription)
            }
        }
    }
    
    // 添加食物
    @MainActor
    func addFood(_ food: FoodItem) async {
        do {
            print("Adding food:", food)
            try await NetworkService.shared.addMealRecord(userId: userId, food: food)
            print("Food added successfully")
            await loadFoods() // 重新加载数据
        } catch {
            print("Error adding food:", error)
            if let urlError = error as? URLError {
                print("URL Error:", urlError.localizedDescription)
            } else {
                print("Other Error:", error.localizedDescription)
            }
        }
    }
    
    // 更新餐点计数
    private func updateMealCounts() {
        var counts: [MealType: Int] = [:]
        for type in MealType.allCases {
            counts[type] = foodItems.filter { 
                $0.mealType == type && 
                Calendar.current.isDate($0.date, inSameDayAs: selectedDate)
            }.count
        }
        mealCounts = counts
    }
    
    /// 日期显示字符串
    var dateString: String {
        let calendar = Calendar.current
        if calendar.isDateInToday(selectedDate) {
            return "Today"
        } else if calendar.isDateInYesterday(selectedDate) {
            return "Yesterday"
        } else if calendar.isDateInTomorrow(selectedDate) {
            return "Tomorrow"
        } else {
            let formatter = DateFormatter()
            formatter.dateFormat = "MMM d, yyyy"
            return formatter.string(from: selectedDate)
        }
    }
    
    /// 前往前一天
    func goToPreviousDay() {
        if let newDate = Calendar.current.date(byAdding: .day, value: -1, to: selectedDate) {
            selectedDate = newDate
        }
    }
    
    /// 前往后一天
    func goToNextDay() {
        if let newDate = Calendar.current.date(byAdding: .day, value: 1, to: selectedDate) {
            selectedDate = newDate
        }
    }
    
    // 添加删除食物的方法
    @MainActor
    func deleteFood(_ food: FoodItem) async {
        do {
            if let serverId = food.serverId {
                // 调用后端 API 删除记录
                try await NetworkService.shared.deleteMealRecord(id: String(serverId))
                // 删除成功后从本地数组中移除
                foodItems.removeAll { $0.id == food.id }
            }
        } catch {
            print("Error deleting food:", error)
        }
    }
}

extension DateFormatter {
    static let yyyyMMdd: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
} 
