import SwiftUI

/// 主内容视图
struct ContentView: View {
    /// 全局视图模型
    @EnvironmentObject private var viewModel: FoodViewModel
    /// 当前选中的标签页索引
    @State private var selectedTab = 1
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 主要内容区域
                TabView(selection: $selectedTab) {
                    HomeView()
                        .tag(1)
                    GoalView()
                        .tag(2)
                    RecordView()
                        .tag(3)
                    FoodView()
                        .tag(4)
                    SettingView()
                        .tag(5)
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                
                // 自定义底部导航栏
                HStack(spacing: 0) {
                    GeometryReader { geometry in
                        HStack(spacing: 0) {
                            TabBarButtonView(
                                icon: "house.fill",
                                isSelected: selectedTab == 1
                            )
                            .onTapGesture { selectedTab = 1 }
                            .offset(y: -8)
                            
                            TabBarButtonView(
                                icon: "magnifyingglass",
                                isSelected: selectedTab == 2
                            )
                            .onTapGesture { selectedTab = 2 }
                            .offset(y: -8)
                            
                            Button(action: { selectedTab = 3 }) {
                                ZStack {
                                    Circle()
                                        .fill(Color.foodPrimary)
                                        .frame(width: 55, height: 55)
                                    
                                    Image(systemName: "camera")
                                        .font(.system(size: 20))
                                        .foregroundColor(.white)
                                }
                            }
                            .offset(y: -10)
                            .frame(width: geometry.size.width / 5)
                            
                            TabBarButtonView(
                                icon: "book",
                                isSelected: selectedTab == 4,
                                strokeStyle: true
                            )
                            .onTapGesture { selectedTab = 4 }
                            .offset(y: -8)
                            
                            TabBarButtonView(
                                icon: "person.fill",
                                isSelected: selectedTab == 5
                            )
                            .onTapGesture { selectedTab = 5 }
                            .offset(y: -8)
                        }
                        .frame(maxHeight: .infinity)
                        .frame(width: geometry.size.width)
                    }
                }
                .frame(height: 50)
                .padding(.horizontal, 30)
                .padding(.bottom, 20)
                .background(Color.white)
            }
        }
    }
}

/// 自定义底部导航按钮
struct TabBarButtonView: View {
    let icon: String
    let isSelected: Bool
    var strokeStyle: Bool = false
    
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 20))
            .foregroundColor(isSelected ? .foodPrimary : .gray)
            .frame(maxWidth: .infinity)
    }
}

/// 首页视图
struct HomeView: View {
    var body: some View {
        Text("Home")
            .navigationTitle("Home")
    }
}

/// 目标视图
struct GoalView: View {
    var body: some View {
        Text("Goal")
            .navigationTitle("Goal")
    }
}

/// 记录视图
struct RecordView: View {
    var body: some View {
        Text("Record")
            .navigationTitle("Record")
    }
}

/// 设置视图
struct SettingView: View {
    var body: some View {
        Text("Setting")
            .navigationTitle("Setting")
    }
}

// MARK: - 预览
#Preview {
    ContentView()
        .environmentObject(FoodViewModel())
}

