import SwiftUI

struct FoodItemRow: View {
    let food: FoodItem
    @EnvironmentObject private var viewModel: FoodViewModel
    @State private var showEditView = false
    @State private var isDeleting = false
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(food.name)
                    .font(.headline)
                HStack {
                    if let amount = food.amount {
                        Text("\(amount, specifier: "%.1f")\(food.unit)")
                        Text("·")
                    }
                    Text("\(food.calories) kcal")
                }
                .font(.subheadline)
                .foregroundColor(.foodGray)
            }
            
            Spacer()
            
            // 编辑按钮
            Button {
                showEditView = true
            } label: {
                Image(systemName: "pencil")
                    .foregroundColor(.blue)
                    .padding(8)
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.blue, lineWidth: 1)
                    )
            }
            .padding(.horizontal, 8)
            
            // 删除按钮
            Button {
                deleteFood()
            } label: {
                Image(systemName: "trash")
                    .foregroundColor(.foodSecondary)
                    .padding(8)
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.foodSecondary, lineWidth: 1)
                    )
            }
            .disabled(isDeleting)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
        )
        .sheet(isPresented: $showEditView) {
            EditFoodView(mealType: food.mealType ?? .breakfast, editingFood: food)
        }
    }
    
    private func deleteFood() {
        guard let id = food.serverId else { return }
        
        isDeleting = true
        
        Task {
            do {
                print("Deleting food with ID:", id)
                try await NetworkService.shared.deleteMealRecord(id: String(id))
                print("Food deleted successfully")
                
                await MainActor.run {
                    isDeleting = false
                    viewModel.foodItems.removeAll { $0.id == food.id }
                }
            } catch {
                print("Error deleting food:", error)
                await MainActor.run {
                    isDeleting = false
                }
            }
        }
    }
}

#Preview {
    FoodItemRow(
        food: FoodItem(
            name: "Apple",
            calories: 52,
            unit: "piece",
            amount: 1,
            mealType: .breakfast,
            date: Date()
        )
    )
    .padding()
    .background(Color.foodBackground)
    .environmentObject(FoodViewModel())
}
