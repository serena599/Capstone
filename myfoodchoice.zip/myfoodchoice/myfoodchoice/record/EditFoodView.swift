import SwiftUI

struct EditFoodView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var viewModel: FoodViewModel
    let mealType: MealType
    let editingFood: FoodItem?
    
    @State private var name: String = ""
    @State private var amount: Double = 1.0
    @State private var unit: String = "g"
    @State private var calories: Int = 0
    
    init(mealType: MealType, editingFood: FoodItem? = nil) {
        self.mealType = mealType
        self.editingFood = editingFood
        
        if let food = editingFood {
            _name = State(initialValue: food.name)
            _calories = State(initialValue: food.calories)
            _unit = State(initialValue: food.unit)
            _amount = State(initialValue: food.amount ?? 1.0)
        }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部导航栏
            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark")
                        .foregroundColor(.white)
                        .font(.system(size: 20))
                }
                
                Spacer()
                
                Text(editingFood == nil ? "Add Food" : "Edit Food")
                    .foregroundColor(.white)
                    .font(.title3)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Button {
                    saveFood()
                } label: {
                    Text("Save")
                        .foregroundColor(.white)
                        .font(.system(size: 17))
                }
            }
            .padding()
            .background(Color.foodPrimary)
            
            ScrollView {
                VStack(spacing: 20) {
                    // 食物名称
                    VStack(alignment: .leading) {
                        Text("Food Name")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        TextField("Enter food name", text: $name)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                    .padding(.horizontal)
                    
                    // 摄入量
                    VStack(alignment: .leading) {
                        Text("Amount")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        HStack {
                            TextField("Enter amount", value: $amount, format: .number)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .keyboardType(.decimalPad)
                            
                            Picker("Unit", selection: $unit) {
                                Text("g").tag("g")
                                Text("serving").tag("serving")
                            }
                            .pickerStyle(.segmented)
                            .frame(width: 120)
                        }
                    }
                    .padding(.horizontal)
                    
                    // 热量
                    VStack(alignment: .leading) {
                        Text("Calories")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        HStack {
                            TextField("Enter calories", value: $calories, format: .number)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .keyboardType(.numberPad)
                            Text("kcal")
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.top)
            }
            .background(Color(.systemGroupedBackground))
        }
        .navigationBarHidden(true)
    }
    
    private func saveFood() {
        // 验证输入
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              calories > 0 else {
            return
        }
        
        let food = FoodItem(
            name: name.trimmingCharacters(in: .whitespacesAndNewlines),
            calories: calories,
            unit: unit.trimmingCharacters(in: .whitespacesAndNewlines),
            amount: amount,
            mealType: mealType,
            date: viewModel.selectedDate
        )
        
        Task {
            await viewModel.addFood(food)
        }
        dismiss()
    }
}

#Preview {
    EditFoodView(mealType: .breakfast)
        .environmentObject(FoodViewModel())
} 
