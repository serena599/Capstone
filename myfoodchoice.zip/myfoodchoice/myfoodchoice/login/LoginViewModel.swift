//
//  LoginViewModel.swift
//  myfoodchoice
//
//  Created by serena on 17/2/2025.
//

import Foundation
import SwiftUI

class LoginViewModel: ObservableObject {
    @Published var username = ""
    @Published var password = ""
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isLoggedIn = false
    @Published var userId: Int = 0
    
    // 使用闭包来管理登录状态
    var onLoginSuccess: (() -> Void)?
    
    func login(completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "http://localhost:4000/api/login") else {
            errorMessage = "Invalid URL"
            completion(false)
            return
        }
        
        let parameters = [
            "username": username,
            "password": password
        ]
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters)
        } catch {
            errorMessage = "Failed to encode parameters"
            completion(false)
            return
        }
        
        isLoading = true
        
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                if let error = error {
                    self?.errorMessage = error.localizedDescription
                    completion(false)
                    return
                }
                
                guard let data = data else {
                    self?.errorMessage = "No data received"
                    completion(false)
                    return
                }
                
                do {
                    if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                        let success = json["success"] as? Bool ?? false
                        if success {
                            if let user = json["user"] as? [String: Any],
                               let userId = user["id"] as? Int {
                                self?.userId = userId
                                self?.isLoggedIn = true
                                self?.onLoginSuccess?()
                                completion(true)
                            } else {
                                self?.errorMessage = "Invalid user data"
                                completion(false)
                            }
                        } else {
                            self?.errorMessage = json["message"] as? String ?? "Login failed"
                            completion(false)
                        }
                    }
                } catch {
                    self?.errorMessage = "Failed to decode response"
                    completion(false)
                }
            }
        }.resume()
    }
    
    func logout() {
        isLoggedIn = false
        userId = 0
    }
} 
