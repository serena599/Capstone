const express = require("express");
const router = express.Router();
const { pool } = require("../databaseConfig");

// 获取所有食物
router.get("/foods", (req, res) => {
  console.log("Received GET /api/foods request");

  pool.query("SELECT * FROM foods ORDER BY id DESC", (error, results) => {
    if (error) {
      console.error("Database error:", error);
      return res.status(500).json({
        message: "查询失败",
        error: error.message,
      });
    }

    console.log("Query results:", results);
    return res.status(200).json({
      message: "查询成功",
      data: results || [],
    });
  });
});

// 添加新食物记录
router.post("/foods", async (req, res) => {
  try {
    console.log("Received POST /api/foods request:", req.body);
    const { name, calories, unit, date, user_id, meal_type, amount } = req.body;

    // 打印 meal_type 值用于调试
    console.log("Meal type received:", meal_type);

    // 验证输入数据
    if (
      !name ||
      calories === undefined ||
      !unit ||
      !user_id ||
      !meal_type ||
      !amount
    ) {
      console.error("Invalid input data:", req.body);
      return res.status(400).json({
        message: "添加食物失败",
        error: "缺少必要字段",
        details: { name, calories, unit, date, user_id, meal_type, amount },
      });
    }

    // 格式化日期为 MySQL 格式 (YYYY-MM-DD)
    const formattedDate = date
      ? new Date(date).toISOString().split("T")[0]
      : new Date().toISOString().split("T")[0];

    const connection = await pool.promise().getConnection();

    try {
      // 开始事务
      await connection.beginTransaction();

      // 直接添加新食物，不检查重复
      const [foodResult] = await connection.query(
        "INSERT INTO foods (name, calories, unit, user_id) VALUES (?, ?, ?, ?)",
        [name.trim(), calories, unit.trim(), user_id]
      );
      const foodId = foodResult.insertId;

      // 添加餐食记录
      const [mealResult] = await connection.query(
        "INSERT INTO meal_records (user_id, food_id, amount, meal_type, record_date) VALUES (?, ?, ?, ?, ?)",
        [user_id, foodId, amount, meal_type.toLowerCase(), formattedDate]
      );

      // 提交事务
      await connection.commit();

      return res.status(200).json({
        message: "添加成功",
        data: {
          id: mealResult.insertId,
          food_id: foodId,
          name: name.trim(),
          calories,
          unit: unit.trim(),
          amount,
          meal_type,
          date: formattedDate,
          user_id,
        },
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({
      message: "添加食物失败",
      error: error.message,
      details: error.stack,
    });
  }
});

// 获取用户的餐食记录
router.get("/meal-records/:userId", async (req, res) => {
  try {
    const { userId } = req.params;
    const { date, meal_type } = req.query;

    // 构建基础 SQL 查询
    let sql = `
      SELECT 
        mr.id,
        mr.food_id,
        f.name,
        f.calories,
        f.unit,
        mr.amount,
        mr.meal_type,
        DATE_FORMAT(mr.record_date, '%Y-%m-%d') as record_date
      FROM meal_records mr
      JOIN foods f ON mr.food_id = f.id
      WHERE mr.user_id = ?
    `;
    let params = [userId];

    // 添加日期过滤
    if (date) {
      sql += " AND DATE(mr.record_date) = ?";
      params.push(date);
    }

    // 添加餐食类型过滤
    if (meal_type) {
      sql += " AND mr.meal_type = ?";
      params.push(meal_type);
    }

    sql += " ORDER BY mr.record_date DESC, mr.meal_type";

    const [results] = await pool.promise().query(sql, params);

    return res.status(200).json({
      message: "查询成功",
      data:
        results.map((record) => ({
          ...record,
          id: record.id.toString(),
        })) || [],
    });
  } catch (error) {
    console.error("Database error:", error);
    return res.status(500).json({
      message: "查询失败",
      error: error.message,
    });
  }
});

// 删除食物记录
router.delete("/meal-records/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const connection = await pool.promise().getConnection();

    try {
      await connection.query("DELETE FROM meal_records WHERE id = ?", [id]);
      connection.release();

      res.json({
        success: true,
        message: "记录已删除",
      });
    } catch (error) {
      connection.release();
      throw error;
    }
  } catch (error) {
    console.error("Delete error:", error);
    res.status(500).json({
      success: false,
      message: "删除失败",
      error: error.message,
    });
  }
});

module.exports = router;
