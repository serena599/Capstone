const express = require("express");
const router = express.Router();
const { pool } = require("../databaseConfig");

// 登录接口
router.post("/login", (req, res) => {
  console.log("Received login request:", req.body);
  const { username, password } = req.body;

  // 验证用户名和密码
  const sql = "SELECT * FROM users_login WHERE username = ? AND password = ?";
  pool.query(sql, [username, password], (error, results) => {
    if (error) {
      console.error("Login error:", error);
      return res.status(500).json({
        success: false,
        message: "登录失败，服务器错误",
      });
    }

    if (results.length > 0) {
      console.log("Login successful for user:", username);
      res.json({
        success: true,
        message: "登录成功",
        user: {
          id: results[0].id,
          username: results[0].username,
        },
      });
    } else {
      console.log("Login failed: Invalid credentials");
      res.json({
        success: false,
        message: "用户名或密码错误",
      });
    }
  });
});

// 注册接口
router.post("/signup", (req, res) => {
  console.log("Received signup request:", req.body);
  const { username, password, email, phone } = req.body;

  // 检查用户名是否已存在
  pool.query(
    "SELECT * FROM users WHERE username = ?",
    [username],
    (error, results) => {
      if (error) {
        console.error("Signup error:", error);
        return res.status(500).json({
          success: false,
          message: "注册失败，服务器错误",
        });
      }

      if (results.length > 0) {
        console.log("Signup failed: Username exists");
        return res.json({
          success: false,
          message: "用户名已存在",
        });
      }

      // 插入新用户
      const sql =
        "INSERT INTO users (username, password, email, phone) VALUES (?, ?, ?, ?)";
      pool.query(sql, [username, password, email, phone], (error, results) => {
        if (error) {
          console.error("User creation error:", error);
          return res.status(500).json({
            success: false,
            message: "注册失败，服务器错误",
          });
        }

        console.log("User created successfully");
        res.json({
          success: true,
          message: "注册成功",
        });
      });
    }
  );
});

module.exports = router;
