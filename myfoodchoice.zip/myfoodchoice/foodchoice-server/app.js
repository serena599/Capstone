const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const { pool } = require("./databaseConfig");
const userRoutes = require("./routes/user");
const foodRoutes = require("./routes/foods");

const app = express();
const port = 4000;

// 中间件
app.use(cors());
app.use(bodyParser.json());

// 测试数据库连接
pool.getConnection((err, connection) => {
  if (err) {
    console.error("数据库连接失败:", err);
    process.exit(1);
  }
  console.log("数据库已连接");
  connection.release();
});

// 路由
app.use("/api", userRoutes);
app.use("/api", foodRoutes);

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({
    message: "服务器错误",
    error: err.message,
    details: err.stack,
  });
});

// 启动服务器
app.listen(port, () => {
  console.log(`服务器正在运行，端口：${port}`);
});
